#ifndef CONFIG_H
#define CONFIG_H

// Comment out this line if your application has a QtGui
#define USE_QTGUI


#define PROGRAM_NAME    "MyFirstComponent"
#define SERVER_FULL_NAME   "RoboComp MyFirstComponent:: MyFirstComponent"

#endif
